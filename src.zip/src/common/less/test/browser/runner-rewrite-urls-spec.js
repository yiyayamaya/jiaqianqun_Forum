describe("less.js browser test - rewrite urls", function() {
    testLessEqualsInDocument();
});
